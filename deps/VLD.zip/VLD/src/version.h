
#define VLDVERSION          L"2.3"
#define VERSION_NUMBER		2,3,0,0
#define VERSION_STRING		"2.3.0.0"
#define VERSION_COPYRIGHT	"Copyright (C) 2005-2013"

#ifndef __FILE__
!define VLD_VERSION "2.3"	// NSIS Script
#endif
